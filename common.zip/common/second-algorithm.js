/*
2. 비어있나요?

- 주어진 값이 비어있는지 확인

    a. 모든 속성 값이 비어있거나 속성 자체가 없으면 빈 값
    b. 배열의 모든 요소가 비어있으면 빈 값
    c. 원시타입은 빈 값이 아님
    d. 빈 문자열은 빈 값
    e. null, undefined 는 빈 값
        ㄴ falsey value 는 빈 값 아님
*/

function isEmpty(value) {
    // null, undefined 검사 먼저 해야함
    
    // e
    if (value === null || value === undefined) return true;

    // c
    if (typeof value === 'number' || typeof value === 'boolean') return false;

    // d
    if (typeof value === 'string') return value.length === 0;

    // b
    if (Array.isArray(value)) {
        return value.every(isEmpty);
    }

    // a
    if (typeof value === 'object') {
        return Object.values(value).every(isEmpty);
    }

    // 그 외의 경우는 비어있지 않다고 판단
    return false;
}

// 테스트 예시
console.log(isEmpty(null)); // true
console.log(isEmpty({})); // true
console.log(isEmpty(0)); // false
console.log(isEmpty(false)); // false
console.log(isEmpty([{}, {a: []}])); // true
console.log(isEmpty({a: null, b: ''})); // true
console.log(isEmpty({a: 1})); // false
console.log(isEmpty([0, "hello"])); // false
