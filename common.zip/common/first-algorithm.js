/*
1. SNS 친구 추천 시스템

- 직접 친구가 아닌 사용자를 추천, 모든 연결 거리의 친구의 친구들을 탐색 -> BFS
- 친구 관계는 양방향 (단방향 X)
- 중복 추천 방지
- 두 번째 매개변수로 주어지는 사용자는 객체 내 존재한다고 가정
*/

function friendRecommendations(network, user) {
    const recommendations = new Set();
    const visited = new Set();
    const queue = [];

    // 사용자 본인과 직접 친구들을 미리 방문 처리하고 큐에 추가
    visited.add(user);
    network[user].forEach(friend => {
        visited.add(friend);
        queue.push(friend);
    });

    // BFS로 친구의 친구 탐색
    while (queue.length > 0) {
        const currentFriend = queue.shift();

        network[currentFriend].forEach(friendOfFriend => {
            if (!visited.has(friendOfFriend)) {
                recommendations.add(friendOfFriend);
                visited.add(friendOfFriend);
            }
        });
    }

    return Array.from(recommendations);
}

// 테스트 데이터
const network = {
    Alice: ["Bob", "Charlie"],
    Bob: ["Alice", "David"],
    Charlie: ["Alice", "Eve"],
    David: ["Bob"],
    Eve: ["Charlie"]
};

// 결과 확인
console.log(friendRecommendations(network, "Alice")); // ["David", "Eve"]
